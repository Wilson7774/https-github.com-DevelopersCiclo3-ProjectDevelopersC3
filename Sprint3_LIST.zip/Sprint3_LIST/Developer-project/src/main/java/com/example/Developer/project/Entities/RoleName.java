package com.example.Developer.project.Entities;

public enum RoleName {
    ADMIN, OPERARIO
}

package com.example.Developer.project.Entities;

public class Enterprise {
    private String nombre;
    private String direccion;
    private String telefono;
    private String nit;

    public Enterprise(String nombre, String direccion, String telefono, String nit){
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.nit = nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }
    public void InformacionEmpresa() {
        System.out.println("Información General " + "\n" +" Nit: " + getNit() +
                "\n"+ " Empresa: " + getNombre() + "\n" + " Telefono: " + getTelefono() +
                "\n" + " Dirección: " + getDireccion()) ;
    }

}

package com.example.Developer.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeveloperProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
